<?php

$GLOBALS['d'] = "../";

?>