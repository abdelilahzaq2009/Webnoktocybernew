<?php
//print debug info
//if this doesn't work, check disable_functions value in php.ini (PHP folder within xampp) and ensure phpinfo is not set as a value
phpinfo();
?>