<?php

?>

<!----- Content / Video ----->
<div class="auto-resizable-iframe">
    <div>
      <iframe src="<?php echo $link ?>" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
    </div>
  </div>